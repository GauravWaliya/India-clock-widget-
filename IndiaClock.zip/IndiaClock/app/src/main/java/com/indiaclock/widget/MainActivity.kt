package com.indiaclock.widget

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

/** Tiny launcher screen that explains how to add the widget. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#101B2B"))
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "India Clock"
            textSize = 28f
            setTextColor(Color.parseColor("#D7B978"))
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "\nTo add the widget: long-press an empty area of your home screen, " +
                "tap Widgets, find \"India Clock\", then drag it onto the screen."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        setContentView(root)
    }
}
