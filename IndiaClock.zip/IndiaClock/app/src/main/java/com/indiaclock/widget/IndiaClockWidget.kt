package com.indiaclock.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews

/**
 * Home-screen widget. Everything (map, clock, date) lives in one layout whose text
 * auto-sizes to boxes placed with layout weights relative to the map image, so it scales
 * perfectly at any widget size without code. Time/date are TextClock views (Asia/Kolkata)
 * updated by the launcher itself: no alarms, services or network, negligible battery use.
 */
class IndiaClockWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            manager.updateAppWidget(id, RemoteViews(context.packageName, R.layout.widget_india_clock))
        }
    }
}
