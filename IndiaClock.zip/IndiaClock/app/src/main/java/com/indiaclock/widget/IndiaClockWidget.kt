package com.indiaclock.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.util.TypedValue
import android.widget.RemoteViews
import kotlin.math.min

/**
 * Home-screen widget. Time/date are rendered by TextClock views (timezone Asia/Kolkata),
 * which the launcher updates itself every minute — no alarms, services or network, so
 * battery use is negligible. This class only re-lays out the clock when the widget is
 * added or resized so it always stays centred inside the map.
 */
class IndiaClockWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) update(context, manager, id)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        update(context, manager, appWidgetId)
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, newOptions)
    }

    companion object {
        // Processed map image is 800 x 878 px.
        private const val MAP_ASPECT = 800f / 878f
        // Centre of the clock inside the map (fractions of map width/height),
        // measured on the central Indian landmass.
        private const val CLOCK_CX = 0.39f
        private const val CLOCK_CY = 0.50f
        // Time + AM/PM row width ~ 0.42 of map width.
        private const val EM_FRACTION = 0.127f
        private const val MAP_PADDING_DP = 8f // must match padding on @id/india_map

        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val opts = manager.getAppWidgetOptions(id)
            val land = context.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            var w = (if (land) opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH)
                     else opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)).toFloat()
            var h = (if (land) opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT)
                     else opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT)).toFloat()
            if (w <= 0f) w = 250f
            if (h <= 0f) h = 250f

            // Fit the map (fitCenter) inside the padded widget area.
            val availW = w - 2 * MAP_PADDING_DP
            val availH = h - 2 * MAP_PADDING_DP
            val mapH = min(availH, availW / MAP_ASPECT)
            val mapW = mapH * MAP_ASPECT
            val mapX0 = (w - mapW) / 2f
            val mapY0 = (h - mapH) / 2f

            // Where the clock's centre must be, relative to the widget centre.
            val dx = (mapX0 + CLOCK_CX * mapW) - w / 2f
            val dy = (mapY0 + CLOCK_CY * mapH) - h / 2f

            val density = context.resources.displayMetrics.density
            fun px(dp: Float) = (dp * density).toInt().coerceAtLeast(0)

            val em = mapW * EM_FRACTION
            val views = RemoteViews(context.packageName, R.layout.widget_india_clock)
            views.setViewPadding(
                R.id.clock_container,
                px(if (dx > 0) 2 * dx else 0f),
                px(if (dy > 0) 2 * dy else 0f),
                px(if (dx < 0) -2 * dx else 0f),
                px(if (dy < 0) -2 * dy else 0f)
            )
            views.setTextViewTextSize(R.id.clock_time, TypedValue.COMPLEX_UNIT_DIP, em)
            views.setTextViewTextSize(R.id.clock_ampm, TypedValue.COMPLEX_UNIT_DIP, em * 0.42f)
            views.setTextViewTextSize(R.id.clock_weekday, TypedValue.COMPLEX_UNIT_DIP, em * 0.34f)
            views.setTextViewTextSize(R.id.clock_date, TypedValue.COMPLEX_UNIT_DIP, em * 0.34f)
            manager.updateAppWidget(id, views)
        }
    }
}
