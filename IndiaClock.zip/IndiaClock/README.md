# India Clock – Android home-screen widget

Native Kotlin App Widget (AppWidgetProvider + RemoteViews + TextClock, Asia/Kolkata).
No internet, no services, no alarms; updatePeriodMillis=0, so battery use is negligible.
Map: app/src/main/res/drawable-nodpi/india_map.png (made from your image: white removed, outline recoloured #D7B978).

## Build the APK (you need to do this once)
1. Install Android Studio (free) and open this folder (File > Open > IndiaClock). Let it sync (needs internet once).
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. APK: app/build/outputs/apk/debug/app-debug.apk
Command line (with Android SDK + JDK 17): `gradle assembleDebug`

## Install on your phone
1. Copy app-debug.apk to the phone, tap it, allow "Install unknown apps" if asked.
2. Long-press empty home screen > Widgets > India Clock > drag it out. Resize by long-pressing it.

## Notes (v2)
- Transparent background; layout is weight-based with auto-sizing text, so map + clock scale together at any size.
- Fonts: Poppins Light/Medium (SIL Open Font License), vertical metrics tightened, tabular digits. Files: app/src/main/res/font/
- Requires Android 8.0+ (API 26).
